import java.util.*;
class Main {
 
  public static void main (String[] args) {
   		
    int a,b,c;
    String s;
     // スキャナーで取得
         Scanner scanner = new Scanner(System.in);
    	 a = scanner.nextInt();
    	 b = scanner.nextInt();
    	 c = scanner.nextInt();
    	
    	 //s = scanner.next();
    
    	System.out.print((a + b + c) + " " + s);
    	
    
  }
  
}