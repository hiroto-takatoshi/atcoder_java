import java.util.*;

public class Main{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        int Y = sc.nextInt();
        int sum = 0;
        int number = 0;
        int doubt = -1;
        int num_i;
        int num_j;
        int num_k;
        int flag = 0;

        for(int i = 0 ; i * 10000 <= Y ; i++){
            for(int j = 0; (j * 5000) +  (i * 10000) <= Y ; j++){
                
                /*
                for(int k = 0; (k * 1000) + (j * 5000) + (i * 10000) <= Y ; k++){
                    sum = (k * 1000) + (j * 5000) + (i * 10000);
                    number = k + j + i;
                    num_i = i;
                    num_j = j;
                    num_k = k;
                    if(sum == Y && number == N && flag == 0){
                        System.out.println(num_i + " " + num_j + " " + num_k);
                        flag = 1;
                        break;
                    }
                }
                */
                
                num_k = N - i - j;
                sum = (num_k * 1000) + (j * 5000) + (i * 10000);
                if(sum == Y){
                    System.out.println(num_i + " " + num_j + " " + num_k);
                    flag = 1;
                    break;                    
                }
                
            }
        }
        if(flag == 0){
            System.out.println(doubt + " " + doubt + " " + doubt);
        }
    }
}