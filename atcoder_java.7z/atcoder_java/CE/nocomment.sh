for file in *.java
do 
   cp "$file" tmp/Main.java
   javac tmp/Main.java 2> "$file.log"
   echo "done $file"
done