import java.util.*;
public class Main {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
        int count = 0;
        String s1 = sc.next();
        if(s1.equals("1"){
              count++; 
        }
        String s2 = sc.next();
        if(s2.equals("1"){
              count++; 
        }
        String s3 = sc.next();
        if(s3.equals("1"){
              count++; 
        }
        // 出力
		System.out.println(count);
	}
}
