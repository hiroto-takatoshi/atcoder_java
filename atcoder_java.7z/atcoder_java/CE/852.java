import java.util.*;
public class Main {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
        String s = null;
        int count = 0;
		for(int i = 0; i<3; i++){
        	s = sc.next();
            if(s.equals("1"){
              count++; 
            }
        }
		// 出力
		System.out.println(count);
	}
}