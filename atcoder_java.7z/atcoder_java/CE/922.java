import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class Main7 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		int N = scan.nextInt(); //カードの枚数
		int Alicesum = 0;
		int Bobsum = 0;

		Integer a [] = new Integer[N] ;

		for (int i = 0; i < N; i++) {
			a[i] = scan.nextInt();
		}

		Arrays.sort(a, Collections.reverseOrder()) ;

		for (int i = 0; i < N; i++) {
			if (a[i] % 2 == 1) {
				Alicesum += a[i];
			}else {
				Bobsum += a[i];
			}
		}
        System.out.println(Alicesum - Bobsum);
	}
}