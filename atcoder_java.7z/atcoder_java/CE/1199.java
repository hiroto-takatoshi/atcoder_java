package pro;
import java.util.*;

public class Otoshidama {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int N = Integer.parseInt(sc.next());
		int Y = Integer.parseInt(sc.next());
		
		int x = -1;
		int y = -1;
		int z = -1;
		
		loops : for(int i = 0; i <= Y / 10000;i++) {
			int zan = N - i;
			for(int w = 0; w <= zan;w++) {
				if(i * 10000 + w * 5000 + (N-i-w) * 1000 == N && i + w + (N-i-w) == N) {
					x = i;
					y = w;
					z = N - i - w;
					break loops;
				}
			}
		}
		System.out.println(x + " " + y + " " + z);
	}
}