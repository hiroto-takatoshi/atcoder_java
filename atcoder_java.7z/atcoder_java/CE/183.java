import java.util.*;
class Main {
 
  public static void main (String[] args) {
   		
    int a,b;
     // スキャナーで取得
         Scanner scanner = new Scanner(System.in);
    	 a = scanner.nextInt();
    	 b = scanner.nextInt();
    	
    	if(a * b % 2 == 0) {
            System.out.println('Even');
        } else {
            System.out.println('Odd');
        }
    
  }
  
}