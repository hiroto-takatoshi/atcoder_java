import java.util.*;
public class Main {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int count = 0;
        int[] a;
        int i = 0;
        for(i = 0; i < n; i++){
          a[i] = sc.nextInt();
        }
        while(true){
          boolean odd_flag = false;
          for(i = 0; i < n; i++){
            if(a[i] % 2 != 0){
              odd_flag = true;  
            }
          }
          if(odd_flag){
            break; 
          }
          for(i = 0; i < n; i++){
            a[i] /= 2;
          }
          count++;
        }
        // 出力
		System.out.println(count);
	}
}
