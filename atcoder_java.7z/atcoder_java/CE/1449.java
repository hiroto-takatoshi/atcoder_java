import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main6 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		int n = scan.nextInt(); //1以上N以下
		int a = scan.nextInt(); //A以上
		int b = scan.nextInt(); //B以下
		int i , j , k , l = 0;

		int [] lista = new int[n]; //1～Nの各桁を足した整数リスト
		List<Integer> listb = new ArrayList<Integer>(); //A以上B以下の整数リスト

		int num = 0; //A以上B以下の整数を合計した値

		for (int x = 0 ; x < n ; x++) {
			i = n % 10000 ;
			j = i % 1000 ;
			k = j % 100 ;
			l = k % 10 ;
			lista[x] = n/10000 + i/1000 + j/100 + k/10 + l ;
//			if (lista[x] >= a && lista[x] <= b) {
//				listb.add(lista[x]);
//			}
		}

		for (int y = 0; y < n; y++) {
			if (lista[y] >= a && lista[y] <= b) {
				listb.add(lista[y]);
			}
		}

		for(int z = 0; z < listb.size() ; z++) {
			num += listb.get(z);
		}
		System.out.println(num);
	}
}