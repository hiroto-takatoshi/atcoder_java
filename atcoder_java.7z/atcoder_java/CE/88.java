import java.util.Scanner;

public class Main6 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		int N = scan.nextInt(); //1以上N以下
		int A = scan.nextInt(); //A以上
		int B = scan.nextInt(); //B以下
		int a,b,c,d,e;
		int sum = 0; //各桁の和
		int num = 0; //A以上B以下の整数を合計した値

		for (int x = 0 ; x <= N ; x++) {
			a = x % 10 ; //1の位
			b = (x/10) % 10 ; //10の位
			c = (x/100) % 10 ; //100の位
			d = (x/1000) % 10 ; //1000の位
			e = (x/10000) % 10 ; //10000の位
			sum = a+b+c+d+e ;
			if (sum >= A && sum <= B) {
				num += x;
			}
		}
		System.out.println(num);
	}
}