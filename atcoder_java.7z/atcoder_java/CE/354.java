public class Main {
	static boolean flg = false;
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		int t[] = new int[n+1];
		int x[] = new int[n+1];
		int y[] = new int[n+1];
		t[0] = 0;
		x[0] = 0;
		y[0] = 0;
		for(int i=1; i<=n; i++) {
			t[i] = scan.nextInt();
			x[i] = scan.nextInt();
			y[i] = scan.nextInt();
		}
		for(int i=0;i<t.length-1;i++) {
			if(t[i+1]-t[i]%2==0) {
				if(Math.abs(x[i+1]+y[i+1]-x[i]-y[i])%2==0 && t[i+1]-t[i]>=Math.abs(x[i+1]+y[i+1]-x[i]-y[i])) {
					flg=true;
				} else {
					flg=false;
					break;
				}
			} else {
				if(Math.abs(x[i+1]+y[i+1]-x[i]-y[i])%2!=0 && t[i+1]-t[i]>=Math.abs(x[i+1]+y[i+1]-x[i]-y[i])) {
					flg=true;
				} else {
					flg=false;
					break;
				}
			}
		}
		if(flg==true) {
			System.out.println("Yes");
		} else {
			System.out.println("No");
		}
	}
}