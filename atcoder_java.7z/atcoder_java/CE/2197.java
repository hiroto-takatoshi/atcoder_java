import java.util.*;
public class Main {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		String str = sc.next();
		scanner.close();
		
        while(str.length()>7){
        	if(str.substring(str.length()-5)=="dream"||str.length()-5)=="erase"){
        		str = str.substring(0,str.length()-5);
        	}else if(str.substring(str.length()-6)=="eraser"){
        		str = str.substring(0,str.length()-6)
        	}else if(str.substring(str.length()-7)=="dreamer"{
        		str = str.substring(0,str.length()-7)
        	}else{
        		sayNo();
        	}
		}
		completeCheck(str);
    }
    
    public static void completeCheck(String str){
        	switch(str){
        	case "dreamer":
        		sayYes();
        		break;
        	case "dream":
        		sayYes();
        		break;
        	case "eraser":
        		sayYes();
        		break;
        	case "erase":
        		sayYes();
        		break;
        	case "":
        		sayYes();
        		break;
        	default:
        		sayNo();
        		break;
        	}
    }

	public static void sayYes(){
		System.out.println("YES");
		System.exit(0);
	}

	public static void sayNo(){
		System.out.println("NO");
		System.exit(0);
	}

}
