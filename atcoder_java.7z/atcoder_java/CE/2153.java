public class Main {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int N = sc.nextInt(); // 札の枚数

		int i ; // 10000円札の枚数
		int j ; // 5000円札の枚数
		// ※1000円札の枚数=（N-i-j）

		int Y = sc.nextInt(); // お年玉の合計
		int total = 0;
		
		
		loop:
		// 考えられるパターンを全て抽出
		for(i = 0 ; i <= N; i++) {
			for(j=0 ; j <=N-i; j++) {

					// 考えられるパターンの額
					total = 10000*i + 5000*j + 1000*(N-i-j);

					// お年玉の合計と同じ額のパターンがある場合
					if(Y == total) {
						System.out.println(i + " " + j + " " + (N-i-j));
						break loop;
					}
			}
		}
		if(Y != total) {
			System.out.println(-1 + " " + -1 + " " + -1);
		}
	}
}
